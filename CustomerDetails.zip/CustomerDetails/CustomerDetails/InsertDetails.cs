﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerDetails
{
    public partial class InsertDetails : Form
    {
        SqlConnection conn;

        public InsertDetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

   

        private void InsertDetails_Load(object sender, EventArgs e)
        {

        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            Customer cust = new Customer();

            cust.CustomerId      = int.Parse(txtid.Value.ToString());
            cust.CustomerName    = txtname.Text;
            cust.CustomerDob     = dtdob.Value.ToString();
            cust.CustomerEmail   = txtemail.Text;
            cust.CustomerContact = Convert.ToInt64(txtcontact.Value.ToString());
            cust.CustomerAddress = txtaddress.Text;
            cust.CustomerMessage = txtmessage.Text;
            

            string sql = String.Format("insert into Customers values({0},'{1}','{2}','{3}',{4},'{5}','{6}')",cust.CustomerId,cust.CustomerName,cust.CustomerDob,cust.CustomerEmail,cust.CustomerContact,cust.CustomerAddress,cust.CustomerMessage);

            MessageBox.Show(sql);
            try{
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfull insertion");
                conn.Close();
            }
            catch(Exception ob)
            {
                Console.WriteLine("data cannot be inserted \n"+ob.Message);
            }
        }
    }
}
