﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerDetails
{
    class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerDob { get; set; }
        public string CustomerEmail { get; set; }
        public long CustomerContact { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerMessage { get; set; }


        public override string ToString()
        {
            string mydata = "";
            mydata += CustomerId.ToString() + "\n";
            mydata += CustomerName.ToString() + "\n";
            mydata += CustomerDob.ToString() + "\n";
            mydata += CustomerEmail.ToString() + "\n";
            mydata += CustomerContact.ToString() + "\n";
            mydata += CustomerAddress.ToString() + "\n";
            mydata += CustomerMessage.ToString() + "\n";

            return mydata;
        }

    }
}
