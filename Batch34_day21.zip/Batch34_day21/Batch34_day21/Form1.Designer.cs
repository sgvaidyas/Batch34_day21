﻿namespace Batch34_day21
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgDept = new System.Windows.Forms.DataGridView();
            this.dgEmp = new System.Windows.Forms.DataGridView();
            this.btnxml = new System.Windows.Forms.Button();
            this.btnjson = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgEmp)).BeginInit();
            this.SuspendLayout();
            // 
            // dgDept
            // 
            this.dgDept.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDept.Location = new System.Drawing.Point(22, 27);
            this.dgDept.Name = "dgDept";
            this.dgDept.Size = new System.Drawing.Size(318, 150);
            this.dgDept.TabIndex = 0;
            // 
            // dgEmp
            // 
            this.dgEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgEmp.Location = new System.Drawing.Point(22, 205);
            this.dgEmp.Name = "dgEmp";
            this.dgEmp.Size = new System.Drawing.Size(688, 182);
            this.dgEmp.TabIndex = 1;
            // 
            // btnxml
            // 
            this.btnxml.Location = new System.Drawing.Point(440, 50);
            this.btnxml.Name = "btnxml";
            this.btnxml.Size = new System.Drawing.Size(109, 50);
            this.btnxml.TabIndex = 2;
            this.btnxml.Text = "CONVERT XML";
            this.btnxml.UseVisualStyleBackColor = true;
            this.btnxml.Click += new System.EventHandler(this.btnxml_Click);
            // 
            // btnjson
            // 
            this.btnjson.Location = new System.Drawing.Point(586, 50);
            this.btnjson.Name = "btnjson";
            this.btnjson.Size = new System.Drawing.Size(114, 50);
            this.btnjson.TabIndex = 3;
            this.btnjson.Text = "CONVERT JSON";
            this.btnjson.UseVisualStyleBackColor = true;
            this.btnjson.Click += new System.EventHandler(this.btnjson_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnjson);
            this.Controls.Add(this.btnxml);
            this.Controls.Add(this.dgEmp);
            this.Controls.Add(this.dgDept);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgEmp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgDept;
        private System.Windows.Forms.DataGridView dgEmp;
        private System.Windows.Forms.Button btnxml;
        private System.Windows.Forms.Button btnjson;
    }
}

