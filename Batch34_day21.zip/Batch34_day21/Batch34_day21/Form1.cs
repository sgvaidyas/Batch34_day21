﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Batch34_day21
{
    public partial class Form1 : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataSet ds;

        public Form1()
        {
            InitializeComponent();
        }

        private DataTable getDeptDetails()
        {
            dt = new DataTable("Department");

            #region Department Datatablecreation
            dc = new DataColumn("deptId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("DepartmentName", typeof(string));
            dt.Columns.Add(dc);

            dr = dt.NewRow();
            dr[0] = 100;
            dr[1] = "CSE";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 101;
            dr[1] = "ECE";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 102;
            dr[1] = "MECH";
            dt.Rows.Add(dr);
            #endregion

            return dt;
        }
        private DataTable getEmpdetails()
        {
            dt = new DataTable("Employees");
            #region Employees region
            dc = new DataColumn("EmpId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Empname", typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("Empsal", typeof(float));
            dt.Columns.Add(dc);

            dc = new DataColumn("DeptId", typeof(int));
            dt.Columns.Add(dc);

            dr = dt.NewRow();
            dr[0] = 1111;
            dr[1] = "Alex";
            dr[2] = 40000;
            dr[3] = 100;
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 1112;
            dr[1] = "Mary";
            dr[2] = 60000;
            dr[3] = 101;
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 1113;
            dr[1] = "Peter";
            dr[2] = 70000;
            dr[3] = 102;
            dt.Rows.Add(dr);
            #endregion
            return dt;
        }

        private DataSet CreateDataSetEmpDb()
        {
            DataTable dept = getDeptDetails();
            DataTable emp = getEmpdetails();

            ds = new DataSet("MyEmployeeDetails");
            ds.Tables.Add(dept);
            ds.Tables.Add(emp);
            //   DataColumn colPrim = ds.Tables["Department"].Columns["deptId"];
            DataColumn colPrim = ds.Tables[0].Columns[0];
            //DataColumn colforkey = ds.Tables["Employees"].Columns["DeptId"];
            DataColumn colforkey = ds.Tables[1].Columns[3];

            DataRelation depemp = new DataRelation("Department Employees", colPrim, colforkey);
            ds.Relations.Add(depemp);

            return ds;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataSet emp_dept = CreateDataSetEmpDb();

            //dgDept.DataSource = emp_dept.Tables["Department"];
            dgDept.DataSource = emp_dept.Tables[0];
            //dgDept.DataSource = emp_dept.Tables["Employees"];
            dgEmp.DataSource = emp_dept.Tables[1];
        }

        private void btnxml_Click(object sender, EventArgs e)
        {
            DataTable dept = getDeptDetails();
            dept.WriteXml("E:\\mydeptdetails.xml");
        }

        private void btnjson_Click(object sender, EventArgs e)
        {
            DataTable dept = getDeptDetails();
            string json = JsonConvert.SerializeObject(dept);
            StreamWriter ob = File.CreateText(@"E:\jsondept.json");
            ob.WriteLine(json);
            ob.Close();
            MessageBox.Show(json);
        }
    }
}
